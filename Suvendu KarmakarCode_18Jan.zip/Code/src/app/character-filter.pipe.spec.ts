import { CharacterFilterPipe } from './character-filter.pipe';

describe('CharacterFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CharacterFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
